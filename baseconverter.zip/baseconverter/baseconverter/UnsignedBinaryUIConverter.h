#include <iostream>
#include <vector>
#include <sstream>
#include <string>
#include <cmath>
using namespace std;

class UnsignedBinaryUIConverter {
private:
	long long _value;
	int _bitRange;
public:
	UnsignedBinaryUIConverter() {
		_value = 0;
		_bitRange = 0;
	}
	UnsignedBinaryUIConverter(long long value, int bitRange) {
		_value = value;
		_bitRange = bitRange;
	}
public:
	bool isValidDec(long long, int);
	bool isValidBin(string);
	vector<int> convertDecToBin(const long long&);
	long long convertBinToDec(string);
	string toString(vector<int>, int);
};