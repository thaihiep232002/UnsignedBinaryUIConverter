#include <iostream>
#include <vector>
#include <sstream>
#include <string>
#include <cmath>
#include "UnsignedBinaryUIConverter.h"
#include "SignedBinaryUIConverter.h"
#include <math.h>
#include <bitset>
#include "RealToBin.h"
#include <iomanip>
#include "IntTobin.h"

using namespace std;

// typedef long long ll;
// typedef unsigned long long ull;

// typedef union {
//     float value; // 4
//     struct {
//         ull man: 23; //8
//         ull ex: 8; //8
//         ull sign: 1; //8
//     };
// } myfloat;

int main() {
    string s, s1;
    FloatToBin ftb;
    IntToBin itb;
    UnsignedBinaryUIConverter ubc;
    SignedBinaryUIConverter sbc;
    bool back = false;
    int choice = -1;
    while (true) {
    menu:
        if (back) break;
        cout << "-----------------------NUMBER CONVERTER------------------------";
        cout << "\nSelect type of number:\n";
        cout << "1. Real number.\n";
        cout << "2. Integer number.\n";
        cout << "3. End.\n";
        cin >> choice;
        switch (choice) {
        case 1:
        doub:
            cout << "1. Convert real number to bin.\n";
            cout << "2. Convert bin to real number.\n";
            cout << "3. Back.\n";
            cin >> choice;
            switch (choice) {
            case 1:
                cout << "Select bit chain.\n";
                cout << "1. 32 bit.\n";
                cout << "2. 64 bit.\n";
                cout << "3. Back.\n";
                cin >> choice;
                switch (choice) {
                case 1: {
                    cout << "Input a floating number: ";
                    cin.ignore(99, '\n');
                    getline(cin, s);
                    cout << "The binary chain is: \n";
                    try {
                        vector<int> binn = ftb.convert_bin_x32bit(s);
                        for (int i = 0; i < binn.size(); i++)
                        {
                            if (i == 1 || i == 9) cout << ' ';
                            cout << binn[i];
                        }
                    }
                    catch (runtime_error ex) {
                        cout << ex.what();
                    }
                    cout << endl;
                    cin.get();
                    goto menu;
                }
                case 2: {
                    cout << "Input a floating number: ";
                    cin.ignore(99, '\n');
                    getline(cin, s);
                    cout << "The binary chain is: \n";
                    try {
                        vector<int> binn = ftb.convert_bin_x64bit(s);
                        for (int i = 0; i < binn.size(); i++)
                        {
                            if (i == 1 || i == 12) cout << ' ';
                            cout << binn[i];
                        }
                    }
                    catch (runtime_error ex) {
                        cout << ex.what();
                    }
                    cout << endl;
                    cin.get();
                    goto menu;
                }
                case 3:
                    goto doub;
                }
            case 2:
                cout << "Select bit chain.\n";
                cout << "1. 32 bit.\n";
                cout << "2. 64 bit.\n";
                cout << "3. Back.\n";
                cin >> choice;
                switch (choice) {
                case 1: {
                    cout << "input your binary pattern: ";
                    cin.ignore(99, '\n');
                    getline(cin, s);
                    cout << "The floating point with single precision is: " << ftb.sp_floating_point_convert(s) << endl;
                    cin.get();
                    goto menu;
                }
                case 2: {
                    cout << "input your binary pattern: ";
                    cin.ignore(99, '\n');
                    getline(cin, s);
                    cout << fixed << setprecision(6);
                    cout << "The floating point with double precision is: " << ftb.dp_floating_point_convert(s) << endl;
                    cin.get();
                    goto menu;
                }
                case 3:
                    goto doub;
                }
            case 3:
                goto menu;
            }
        case 2:
        inte:
            cout << "1.Convert int to bin.\n";
            cout << "2.Convert bin to int.\n";
            cout << "3.Back.\n";
            cin >> choice;
            switch (choice) {
            case 1:
                cout << "Select bit chain.\n";
                cout << "1. 8 bit.\n";
                cout << "2. 16 bit.\n";
                cout << "3. 32 bit.\n";
                cout << "4. Back.\n";
                cin >> choice;
                switch (choice) {
                case 1:
                    cout << "Input an integer number: ";
                    long long n8; cin >> n8;
                    if (ubc.isValidDec(n8, 8)) {
                        vector<int> data = ubc.convertDecToBin(n8);
                        string result = ubc.toString(data, 8);
                        cout << "The unsigned bit range is : " << result << endl;
                    }
                    if (sbc.isValidDec(n8, 8)) {
                        vector<int> data = sbc.convertDecToBin(n8, 8);
                        string result = sbc.toString(data);
                        cout << "The signed bit range is : " << result << endl;
                    }
                    cin.get(); goto menu;
                case 2:
                {
                    cout << "Input an integer number: ";
                    long long n16; cin >> n16;
                    if (ubc.isValidDec(n16, 16)) {
                        vector<int> data = ubc.convertDecToBin(n16);
                        string result = ubc.toString(data, 16);
                        cout << "The unsigned bit range is : " << result << endl;
                    }
                    if (sbc.isValidDec(n16, 16)) {
                        vector<int> data = sbc.convertDecToBin(n16, 16);
                        string result = sbc.toString(data);
                        cout << "The signed bit range is : " << result << endl;
                    }
                    cin.get(); goto menu;
                }
                case 3:
                    cout << "Input an unsigned integer number: ";
                    long long n32; cin >> n32;
                    if (ubc.isValidDec(n32, 32)) {
                        vector<int> data = ubc.convertDecToBin(n32);
                        string result = ubc.toString(data, 32);
                        cout << "The unsigned bit range is : " << result << endl;
                    }
                    if (sbc.isValidDec(n32, 32)) {
                        vector<int> data = sbc.convertDecToBin(n32, 32);
                        string result = sbc.toString(data);
                        cout << "The signed bit range is : " << result << endl;
                    }
                    cin.get(); goto menu;
                case 4:
                    goto inte;
                }
            case 2:
                cout << "Select bit chain.\n";
                cout << "1. 8 bit.\n";
                cout << "2. 16 bit.\n";
                cout << "3. 32 bit.\n";
                cout << "4. Back.\n";
                cin >> choice;
                switch (choice) {
                case 1: {
                    cout << "Input a bit pattern: ";
                    cin.ignore();
                    string n8; getline(cin, n8);
                    int len_n8 = n8.size();
                    if (len_n8 > 8) {
                        n8 = n8.substr(0, 8);
                    }
                    if (ubc.isValidBin(n8)) {
                        long long result = ubc.convertBinToDec(n8);
                        cout << "The unsigned integer is : " << result <<endl;
                    }
                    if (sbc.isValidBin(n8)) {
                        long long result = sbc.convertBinToDec(n8);
                        cout << "The signed integer is : " << result << endl;
                    }
                    cin.get();
                    goto menu;
                }
                case 2: {
                    cout << "Input a bit pattern: ";
                    cin.ignore();
                    string n16; getline(cin, n16);
                    int len_n16 = n16.size();
                    if (len_n16 > 16) {
                        n16 = n16.substr(0, 16);
                    }
                    if (ubc.isValidBin(n16)) {
                        long long result = ubc.convertBinToDec(n16);
                        cout << "The unsigned integer is : " << result << endl;
                    }
                    if (sbc.isValidBin(n16)) {
                        long long result = sbc.convertBinToDec(n16);
                        cout << "The signed integer is : " << result << endl;
                    }
                    cin.get();
                    goto menu;
                }
                case 3: {
                    cout << "Input a bit pattern: ";
                    cin.ignore();
                    string n32; getline(cin, n32);
                    if (ubc.isValidBin(n32)) {
                        long long result = ubc.convertBinToDec(n32);
                        cout << "The unsigned integer is : " << result << endl;
                    }
                    if (sbc.isValidBin(n32)) {
                        long long result = sbc.convertBinToDec(n32);
                        cout << "The signed integer is : " << result << endl;
                    }
                    cin.get();
                    goto menu;
                }
                case 4:
                    goto inte;
                }
            case 3:
                goto menu;
            }
        case 3:
            back = true;
            break;
        }
    }
}